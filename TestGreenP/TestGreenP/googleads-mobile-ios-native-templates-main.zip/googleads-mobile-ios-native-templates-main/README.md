# Native Templates iOS

This repository contains a directory with two template views that you can use
with Native ads in your applications.

See https://developers.google.com/admob/ios/native/templates for documentation
on using these templates.
